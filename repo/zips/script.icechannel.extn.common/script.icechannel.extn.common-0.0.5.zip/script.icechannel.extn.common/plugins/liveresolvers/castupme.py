'''
    Ice Channel
'''

from entertainment.plugnplay.interfaces import LiveResolver
from entertainment.plugnplay import Plugin
from entertainment import common

class castupme(LiveResolver):
    implements = [LiveResolver]
    
    name = 'castup.me'
    
    def ResolveLive(self, content, url):
    
        import re
        
        new_content = re.search("<script.+?fid=[\"'](.+?)[\"'].+?src=[\"']http://www\.castup\.me/js/embed\.js[\"']", content)

        if new_content:
        
            page_url = 'http://www.castup.me/embed.php?channel=' + new_content.group(1)
            
            from entertainment.net import Net
            net = Net(http_debug=True)            
            content = net.http_GET( page_url, headers={'Referer':url} ).content
            
            swf_url = re.search( "SWFObject\([\"'](.+?)[\"']" ,content).group(1)
            playpath = re.search( "so.addVariable\([\"']file[\"'].+?[\"'](.+?)[\"']" ,content).group(1)
            streamer = re.search( "so.addVariable\([\"']streamer[\"'].+?[\"'](.+?)[\"']" ,content).group(1)
            token = re.search( "so.addVariable\([\"']token[\"'].+?[\"'](.+?)[\"']" ,content).group(1)
            
            content = streamer + ' playpath=' + playpath + ' swfUrl=' + swf_url + ' pageUrl=' + page_url + ' token=' + token + ' timeout=20 live=true'
            
            return (True, True, content, url)
            
        return (False, False, content, url)
