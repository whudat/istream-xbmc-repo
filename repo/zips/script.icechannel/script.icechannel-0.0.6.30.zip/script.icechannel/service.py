from entertainment import common
import os

services_path = os.path.join(common.addon_path, 'services')

for dirpath, dirnames, files in os.walk(services_path):
    for f in files:
        if f.endswith('.py'):
            service_py = os.path.join(dirpath, f)
            cmd = 'RunScript(%s,%s)' % (service_py, '1')
            xbmc.executebuiltin(cmd)
