'''
    Ice Channel
'''

import os    
import sys
from addon import Addon

addon_id = 'script.icechannel'

try:
    addon = Addon(addon_id, sys.argv)
except:
    addon = Addon(addon_id)

addon_path = addon.get_path()
addon_version = addon.get_version()

plugins_path = os.path.join(addon_path, 'lib', 'entertainment', 'plugins')
settings_file = os.path.join(addon_path, 'resources', 'settings.xml')

profile_path = addon.get_profile()

theme_dir = addon.get_setting('theme').lower().replace(' ', '')
if theme_dir.lower() == 'default':
    icon_path = 'https://istream-xbmc-repo.googlecode.com/svn/images/'
else:
    icon_path = os.path.join(addon_path, 'themes', theme_dir)

def get_themed_icon(icon_file_name):
    if icon_path.startswith('http'):
        icon = icon_path + icon_file_name
    else:
        icon = os.path.join(icon_path, icon_file_name)
        if not os.path.exists( icon ):
            icon = 'https://istream-xbmc-repo.googlecode.com/svn/images/' + icon_file_name
    return icon
    
icon = get_themed_icon('icon.png')    
notify_icon = get_themed_icon('notifyicon.png')

# INDEXERS
indxr_Movies = 'movies'
indxr_TV_Shows = 'tv_shows'
indxr_Sports = 'sports'
indxr_Lists = 'lists'
indxr_Live_TV = 'live_tv'

# SOURECS
src_Movies = 'movies'
src_TV_Shows = 'tv_shows'
src_Sports = 'sports'
src_Live_TV = 'live_tv'

# SETTINGS
settings_Movies = 'movies'
settings_TV_Shows = 'tv_shows'
settings_Sports = 'sports'
settings_Lists = 'lists'
settings_About = 'about'
settings_XBMC_Integration = 'xbmcintegration'
settings_Live_TV = 'live_tv'

# MODES
mode_Main = 'main'
mode_Indexer = 'indexer'
mode_Section = 'section'
mode_Content = 'content'
mode_Info = 'info'
mode_File_Hosts = 'file_hosts'
mode_Play = 'play'
mode_Play_Trailer = 'play_trailer'
mode_Search = 'search'
mode_Settings = 'settings'
mode_Dummy = 'dummy'
mode_Sports = 'sports'
mode_Sports_Links = 'sports_links'
mode_Change_Watched = 'change_watched'
mode_Refresh_Meta = 'refresh_meta'
mode_Add_To_Favorites = 'add_to_favorites'
mode_Add_To_Library = 'add_to_library'
mode_Subscribe = 'subscribe'
mode_Unsubscribe = 'unsubscribe'
mode_Manage_Subs = 'manage_subs'
mode_Update_Subs = 'update_subs'
mode_Clean_Up_Subs = 'clean_up_subs'
mode_File_Stores = 'file_stores'
mode_Add_File_Store = 'add_file_stores'
mode_Add_Http_File_Store = 'add_http_file_stores'
mode_Add_Local_File_Store = 'add_local_file_stores'
mode_Read_File = 'read_file'
mode_Read_File_Item = 'read_file_item'
mode_Rename_File_Item = 'rename_file_item'
mode_Play_File_Item = 'play_file_item'
mode_Read_File_Item_2 = 'read_file_item_2'
mode_Add_File_Item = 'add_file_item'
mode_Remove_File_Item = 'remove_file_item'
mode_Remove_Play_List_Source = 'remove_playlist_source'
mode_Play_List_Sources = 'playlist_sources'
mode_Play_Lists = 'playlists'
mode_Live_TV = 'live_tv'
mode_Live_TV_Regions = 'live_tv_regions'
mode_Live_TV_Region = 'live_tv_region'
mode_Live_TV_Languages = 'live_tv_languages'
mode_Live_TV_Language = 'live_tv_language'
mode_Live_TV_Genres = 'live_tv_genres'
mode_Live_TV_Genre = 'live_tv_genre'
mode_Live_TV_Links = 'live_tv_links'
mode_Hide_Channel = 'hide_channel'
mode_Tools = 'tools'

# SECTIONS
id_Section_Main = 'main'

# VIDEO TYPES FOR META-DATA
VideoType_Movies = 'movie'
VideoType_TV = 'tvshow'
VideoType_Season = 'season'
VideoType_Episode = 'episode'

# Global Peoperties
gb_Lib_Subs_Op_Running = 'lib_subs_op_running'

def make_dir(mypath, dirname):
    ''' Creates sub-directories if they are not found. '''
    import xbmcvfs
    
    if not xbmcvfs.exists(mypath): 
        try:
            xbmcvfs.mkdirs(mypath)
        except:
            xbmcvfs.mkdir(mypath)
    
    subpath = os.path.join(mypath, dirname)
    
    if not xbmcvfs.exists(subpath): 
        try:
            xbmcvfs.mkdirs(subpath)
        except:
            xbmcvfs.mkdir(subpath)
            
    return subpath
    
cookies_path = make_dir(profile_path, 'cookies')    
captchas_path = make_dir(profile_path, 'captchas')

def CleanText(text, strip=False, remove_non_ascii=False):
    from entertainment import htmlcleaner
    import urllib
    text = htmlcleaner.clean( urllib.unquote_plus(text), strip, remove_non_ascii )
    return text    
    
def CleanText2(text, strip=False, remove_non_ascii=False):
    from entertainment import htmlcleaner
    import urllib
    text = htmlcleaner.clean2( urllib.unquote_plus(text), strip, remove_non_ascii )
    return text    

def CreateIdFromString(str):
    str = CleanText(str, False, True)
    import re
    id = re.sub('[^0-9a-zA-Z]+', '_', str).lower()
    if id.endswith('_'): id = id[:-1]
    
    return id
    
def CleanTextForSearch(text, strip=False, remove_non_ascii=False):
    from entertainment import htmlcleaner
    import urllib
    text = htmlcleaner.clean( urllib.unquote_plus(text), strip, remove_non_ascii )
    return text
    
def GetDomainFromUrl(url):
    import re
    domain = re.sub('(http://|https://|http://www.|https://www.|www.)', '', url)
    domain = re.sub('/.*', '', domain)
    if domain[len(domain)-1] == ':': domain = domain[:-1]
    if re.search('[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}', domain): domain = 'ip'
    return domain.upper()
    
def GetBaseUrlFromUrl(url):
    import re
    index = url.find('/', url.find('.')) + 1
    base_url = url[:index]
    if not base_url.endswith('/') : base_url = base_url + '/'
    return base_url
    
    
def unescape(text):
        try:            
            rep = {"&nbsp;": " ",
                   "\r": "",            
                   "\n": "",
                   "\t": ""
                   }
            for s, r in rep.items():
                text = text.replace(s, r)
				
            # remove html comments
            import re
            text = re.sub(r"<!--.+?-->", "", text)    

        except TypeError:
            pass

        return text

def str_conv(data):
    if isinstance(data, str):
        # Must be encoded in UTF-8
        data = data.decode('utf8', 'ignore')
    import unicodedata
    data = unicodedata.normalize('NFKD', data).encode('ascii','ignore')
    data = data.decode('string-escape')
    return data
    
##### DECODE / ENCODE LIST
########## START
def encode_item_for_list(item):
    if isinstance(item, str) or isinstance(item, unicode) :
        if item.find(',') >= 0:
            item = item.replace(',', '<listcomma>')
    return item
    
def decode_item_for_list(item):
    if isinstance(item, str) or isinstance(item, unicode) :            
        if item.find('<listcomma>') >= 0:
            item = item.replace('<listcomma>', ',')
    return item
    
def encode_list(in_list):
    out_list = []
    for item in in_list:
        if isinstance(item, dict):
            out_list.append( encode_item_for_list( ConvertDictToString(item) ) )
        else:
            out_list.append( encode_item_for_list(item) )
        
    return out_list
    
def decode_list(in_list):
    out_list = []
    
    for item in in_list:
        if item[1] == '{' and item[len(item)-2] == '}': 
            item = item[1:len(item)-1]
            out_list.append( ConvertStringToDict( decode_item_for_list(item) ) )
        else:
            out_list.append( decode_item_for_list(item) )

    return out_list

def ConvertListToString(in_list):
    return str ( encode_list(in_list) )
    
def ConvertStringToList(in_string):

    in_string = in_string.replace(' , ', ',')
    in_string = in_string.replace(', ', ',')
    in_string = in_string.replace(' ,', ',')
    in_string = in_string[1:len(in_string)-1]

    return decode_list ( in_string.split(',') )
    
########## END
##### ENCODE / DECODE LIST


##### ENCODE / DECODE DICT
########## START
def encode_dict(dict):
    out_dict = {}
    for k, v in dict.iteritems():
        if isinstance(k, str) or isinstance(k, unicode) :            
            k = str_conv(k)
            if k.find(',') >= 0:
                k = k.replace(',', '<dictcomma>')
            if k.find("'") >= 0:
                k = k.replace("'", '<squot>')
            if k.find('"') >= 0:
                k = k.replace('"', '<dquot>')
            if k.find('{') >= 0:
                k = k.replace('{', '<ltbrc>')
            if k.find('}') >= 0:
                k = k.replace('}', '<rtbrc>')
            if k.find(':') >= 0:
                k = k.replace(':', '<colon>')
        if isinstance(v, str) or isinstance(v, unicode) :            
            v = str_conv(v)
            if v.find(',') >= 0:
                v = v.replace(',', '<dictcomma>')
            if v.find("'") >= 0:
                v = v.replace("'", '<squot>')
            if v.find('"') >= 0:
                v = v.replace('"', '<dquot>')
            if v.find('{') >= 0:
                v = v.replace('{', '<ltbrc>')
            if v.find('}') >= 0:
                v = v.replace('}', '<rtbrc>')
            if v.find(':') >= 0:
                v = v.replace(':', '<colon>')
        out_dict[k] = v
    return out_dict
    
def decode_dict(dict):
    out_dict = {}
    for k, v in dict.iteritems():
        if isinstance(k, str) or isinstance(k, unicode):
            k = str_conv(k)
            if k.find('<dictcomma>') >= 0:
                k = k.replace('<dictcomma>', ',')
            if k.find("<squot>") >= 0:
                k = k.replace("<squot>", "'")
            if k.find('<dquot>') >= 0:
                k = k.replace("<dquot>", '"')
            if k.find('<ltbrc>') >= 0:
                k = k.replace('<ltbrc>', '{')
            if k.find('<rtbrc>') >= 0:
                k = k.replace('<rtbrc>', '}')
            if k.find('<colon>') >= 0:
                k = k.replace('<colon>', ':')
        if isinstance(v, str) or isinstance(v, unicode):
            v = str_conv(v)
            if v.find('<dictcomma>') >= 0:
                v = v.replace('<dictcomma>', ',')
            if v.find("<squot>") >= 0:
                v = v.replace("<squot>", "'")
            if v.find('<dquot>') >= 0:
                v = v.replace("<dquot>", '"')
            if v.find('<ltbrc>') >= 0:
                v = v.replace('<ltbrc>', '{')
            if v.find('<rtbrc>') >= 0:
                v = v.replace('<rtbrc>', '}')
            if v.find('<colon>') >= 0:
                v = v.replace('<colon>', ':')        
        out_dict[k] = v
    return out_dict    

def ConvertDictToString(in_dict):
    return str ( encode_dict(in_dict) )
    
def ConvertStringToDict(in_string):
    
    try:
        import json
    except:
        import simplejson as json
        
    import re
        
    return decode_dict ( json.loads(re.sub(r",\s*(\w+)", r", '\1'", re.sub(r"\{(\w+)", r"{'\1'", in_string.replace('\\','\\\\'))).replace("'", '"')) )
    
def dict_to_paramstr(dict):
    out_dict = {}
    for k, v in dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    
    import urllib    
    return urllib.urlencode(out_dict)
    
def parse_query(query):
    import cgi
    queries = cgi.parse_qs(query)
    q = {}
    for key, value in queries.items():
        if len(value) == 1:
            q[key] = value[0]
        else:
            q[key] = value
    return q
########## END
##### ENCODE / DECODE DICT

def ttTTtt(i, t1, t2=[]):
    t = ''
    for c in t1:
        t += chr(c)
        i += 1
        if i > 1:
            t = t[:-1]
            i = 0  
    for c in t2:
        t += chr(c)
        i += 1
        if i > 1:
            t = t[:-1]
            i = 0
    return t

# TIMEZONE OFFSET
def get_gmt_offset():
    import time
    t = time.time()
    
    gmt_offset = 0
    
    if time.localtime(t).tm_isdst and time.daylight:
        gmt_offset = time.altzone
    else:
        gmt_offset = time.timezone
        
    gmt_offset = gmt_offset / 60 / 60 * -1
    
    return gmt_offset
    
class Threaded_Notification:
    def __init__(self, duration=1000, msg='Working', msg2=''):
        import threading
        self._task_complete = threading.Event()
        
        self._title = '[COLOR white]' + msg + '[/COLOR]' 
        self._msg2 = '[COLOR orange]' + msg2 + '[/COLOR]'
        self._duration = duration
        self._icon = notify_icon
        
        self._completion_msg1 = ''
        self._completion_msg2 = ''
        
        self._progress_symbol = '*'
        self._progress_count = 5
        self._progress_current_index = 0
        
        threading.Thread(target=self.show_xunity_working_notification).start()
        
    def SetTaskCompletionMessage(self, msg1, msg2):
        self._completion_msg1 = '[COLOR white]' + msg1 + '[/COLOR]'
        self._completion_msg2 = '[COLOR orange]' + msg2 + '[/COLOR]'
    
    def SetTaskCompletion(self, completion_msg1='Completed', completion_msg2=''):
        self.SetTaskCompletionMessage(completion_msg1, completion_msg2)
        self._task_complete.set()
        
    def SetMessage2(self, msg):
        self._msg2 = '[COLOR orange]' + msg + '[/COLOR]'
        
    def _check_exit_status(self):
        import xbmc
        return ( self._task_complete.isSet() or xbmc.abortRequested)
        
    def _generate_indicator(self):
        if self._progress_current_index > self._progress_count:
            self._progress_current_index = 1
        else:    
            self._progress_current_index += 1
        return ' [B][[COLOR gray]' + ( (self._progress_current_index-1) * self._progress_symbol) + '[/COLOR][COLOR cyan]' + self._progress_symbol + '[/COLOR][COLOR gray]' + ( (self._progress_count-(self._progress_current_index-1)) * self._progress_symbol) + '[/COLOR]][/B]'
                
    def show_xunity_working_notification(self):
        import xbmc
        
        msg = self._generate_indicator()
        addon.show_small_popup(self._title + msg, self._msg2, self._duration, self._icon)
        
        while not self._check_exit_status():
            xbmc.sleep(self._duration)
            msg = self._generate_indicator()
            if self._check_exit_status(): break;
            addon.show_small_popup(self._title + msg, self._msg2, self._duration, self._icon)
            
        addon.show_small_popup(self._completion_msg1, self._completion_msg2, self._duration, self._icon)
            

    
def notify(addon_id, typeq, title, message, times, line2='', line3=''):
    import xbmc
    addon_tmp = Addon(addon_id)
    if title == '' :
        title='[B]' + addon_tmp.get_name() + '[/B]'
    if typeq == 'small':
        if times == '':
           times='5000'
        smallicon= notify_icon
        xbmc.executebuiltin("XBMC.Notification("+title+","+message+","+times+","+smallicon+")")
    elif typeq == 'big':
        dialog = xbmcgui.Dialog()
        dialog.ok(' '+title+' ', ' '+message+' ', line2, line3)
    else:
        dialog = xbmcgui.Dialog()
        dialog.ok(' '+title+' ', ' '+message+' ')        
        
def SetScriptOnAlarm(name, path, args='1', duration=1440):    
    import xbmc
    cmd       = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % (name, path, args, duration)
    xbmc.executebuiltin(cmd)
    
def GetTotalMinutesFromTimeDelta(td):
    td_total_mins = ( td.days * 24 * 60 ) + ( td.seconds / 60 )    
    td_total_mins = int(td_total_mins)
    if td_total_mins <= 0: td_total_mins = 1
    return td_total_mins
    
def SetGlobalProperty(id, value):
    import xbmcgui
    win = xbmcgui.Window(10000)
    win.setProperty(addon_id + '.' + id, str(value) )
    
def GetGlobalProperty(id):
    import xbmcgui
    win = xbmcgui.Window(10000)
    return win.getProperty(addon_id + '.' + id)
    
def ClearGlobalProperty(id):
    import xbmcgui
    win = xbmcgui.Window(10000)
    win.clearProperty(addon_id + '.' + id)
    
def GetEpochStr():
    import datetime
    time_now=datetime.datetime.now()
    
    import time
    epoch=time.mktime(time_now.timetuple())+(time_now.microsecond/1000000.)
    
    epoch_str = str('%f' % epoch)
    epoch_str = epoch_str.replace('.','')
    epoch_str = epoch_str[:-3]

    return epoch_str

from entertainment import odict
quality_dict = odict.odict({
    'ts'            : 'TS',
    'hdts'          : 'TS',
    'tsrip'         : 'TS',
    'cam'           : 'CAM',
    'camrip'        : 'CAM',
    'hdcam'         : 'CAM',
    'dvdscr'        : 'DVD',
    'dvdrip'        : 'DVD',
    'dvd'           : 'DVD',
    'brrip'         : 'HD',
    'bdrip'         : 'HD',
    'bluray'        : 'HD',
    'hd'            : 'HD',
    '720p'          : '720P',
    '1080p'         : '1080P'
    })
    
movie_container_dict = odict.odict( {    
    'mkv'           : 'MKV',
    'mp4'           : 'MP4',
    'avi'           : 'AVI'
    })
        
def RemoveNonAscii(text):
    import re
    cleaned = re.sub(r'[^\x00-\x7F]+',' ', text)
    return cleaned
    
def makeGUID():
    import random
    guid = ''
    for i in range(8):
        number = "%X" % (int( ( 1.0 + random.random() ) * 0x10000) | 0)
        guid += number[1:]
    return guid
    
def AES(key):
    from crypto.cipher.base import padWithPadLen
    from crypto.cipher.rijndael import Rijndael
    return Rijndael(key, keySize=32, blockSize=16, padding=padWithPadLen())

def AES_CBC(key):
    from crypto.cipher.cbc import CBC
    return CBC(blockCipherInstance=AES(key))    
    
def handle_captcha(url, html, params=None):
    '''
    return dict, possible values
    1. {'status':'none'} - No captcha Found.
    2. {'status':'error', 'message':'<error message>', 'captch_type':'<which captcha was found>'} 
    3. {'status':'error', 'message':'<error message>', 'captch_type':'<which captcha was found>, 
            'captcha':<the self resolved or user entered captcha value>, 
            ... (any other paramters found to go with captcha for e.g adcopy_challenge:hugekey incase of solvemedia)
        } 
    '''
    captcha_dict = {'status':'none'}
    captcha_resolved = False
    
    from entertainment.plugnplay.interfaces import CaptchaHandler
    for ch in CaptchaHandler.implementors():
        captcha_resolved = ch.CanHandle(url, html, params=params)
        if captcha_resolved == True:
            captcha_dict = ch.Handle(url, html, params=params)
            if captcha_dict:
                break
            else:
                captcha_resolved = False
                
    return captcha_dict