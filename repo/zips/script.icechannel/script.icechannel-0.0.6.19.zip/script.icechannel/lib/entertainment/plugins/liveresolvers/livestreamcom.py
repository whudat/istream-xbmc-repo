'''
    Ice Channel
'''

from entertainment.plugnplay.interfaces import LiveResolver
from entertainment.plugnplay import Plugin
from entertainment import common

class livestreamcom(LiveResolver):
    implements = [LiveResolver]
    
    name = 'livestream.com'
    
    def ResolveLive(self, content, url):
    
        import re
        new_content = re.search("<iframe.+?src=[\"']http://.+?livestream\.com/embed/(.+?)\?", content)
        
        if new_content:
            channel_id = new_content.group(1)
            playable_url = 'http://x%sx.api.channel.livestream.com/3.0/playlist.m3u8' % channel_id
            return (True, True, playable_url, url)
            
        return (False, False, content, url)
