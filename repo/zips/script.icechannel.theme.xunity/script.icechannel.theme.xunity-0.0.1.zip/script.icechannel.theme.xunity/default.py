addon_id="script.icechannel.theme.xunity"
addon_name="iStream Theme - Xunity"