'''
    Ice Channel
'''

from entertainment.plugnplay.interfaces import LiveTVSource
from entertainment.plugnplay import Plugin
from entertainment.plugnplay.interfaces import CustomSettings
from entertainment import common
import xml.dom.minidom as dom

class bbciplayer(LiveTVSource,CustomSettings):
    implements = [LiveTVSource,CustomSettings]
    
    display_name = "BBC iPLAYER"
    
    name = 'BBC iPLAYER'
    
    source_enabled_by_default = 'true'
    
    def __init__(self):
        xml = '<settings>\n'
        xml += '<category label="General">\n'
        xml += '<setting id="uk_proxy" type="bool" label="Use UK Proxy" default="false"/>\n'
        xml += '<setting id="provider" label="Stream Source Preference" type="enum" values="Any|Akamai|Limelight|Level3" default="0" />\n'
        xml += '<setting id="protocol" label="Protocal (try rtmpt if firewalled)" type="enum" values="rtmp (port 1935)|rtmpt (port 80)" default="r0" />\n'
        xml += '</category>\n' 
        xml += '</settings>\n'
        self.CreateSettings(self.name, self.display_name, xml)    

    
    def parseXML(self,url):
        from entertainment.net import Net
        net = Net(cached=False)
        xml = net.http_GET(url).content
        doc = dom.parseString(xml)
        root = doc.documentElement
        return root

    def GetFileHosts(self, id, other_names, region, language, list, lock, message_queue):
        
        stream_id = None
        
        if id =='bbc_one':
            stream_id='bbc_one_london'
        
        elif id =='bbc_two':
            stream_id='bbc_two_england'
        
        elif 'cbeeb' in id:
            stream_id='bbc_four'
        
        if not stream_id: return
        
        surl = 'http://www.bbc.co.uk/mediaselector/4/mtis/stream/%s' % stream_id

        if self.Settings().get_setting('uk_proxy')=='true':
            import base64
            root = self.parseXML('http://www.justproxy.co.uk/index.php?q='+base64.b64encode(surl))
        else:
            root = self.parseXML(surl)
        mbitrate = 0
        url = ""
        if root.getElementsByTagName( "error" ) and root.getElementsByTagName( "error" )[0].attributes["id"].nodeValue == 'notavailable': return ""
        medias = root.getElementsByTagName( "media" )

        quality_dict = {'1500':'HD', '800':'HD', '560':'HD', '480':'HD', '396':'SD', '176':'LOW', '56':'LOW'}
        
        for media in medias:

            conn_  = media.getElementsByTagName( "connection" )

            for conn in conn_:

                # rtmp streams
                identifier  = conn.attributes['identifier'].nodeValue
                server      = conn.attributes['server'].nodeValue
                auth        = conn.attributes['authString'].nodeValue
                supplier    = conn.attributes['supplier'].nodeValue

                # not always listed for some reason
                try:
                    application = conn.attributes['application'].nodeValue
                except:
                    application = 'live'

                params = dict(protocol = self.get_protocol(), port = self.get_port(), server = server, auth = auth, ident = identifier, app = application)
                
                res =identifier.split('inlet_')[1]
                
                if '@' in res:
                    res=res.split('@')[0]
                    
                if supplier == "akamai" or supplier == "limelight":
                    if supplier == "akamai":
                        url = "%(protocol)s://%(server)s:%(port)s/%(app)s/?%(auth)s playpath=%(ident)s?%(auth)s" % params
                    if supplier == "limelight":
                        url = "%(protocol)s://%(server)s:%(port)s/ app=%(app)s?%(auth)s tcurl=%(protocol)s://%(server)s:%(port)s/%(app)s?%(auth)s playpath=%(ident)s" % params
                    url += " swfurl=http://www.bbc.co.uk/emp/10player.swf swfvfy=1 live=1"
                elif supplier == "akamai_hd":
                    url = conn.attributes['href'].nodeValue

                self.AddLiveLink( list, id.replace('_',' ').upper(), url, language = language.title(),host= 'BBC iPLAYER '+supplier,quality=quality_dict.get(res, 'NA'))

    def get_provider(self):
        provider = ""
        try:
            provider_id = self.Settings().get_setting('provider')
        except:
            pass

        if   provider_id == '1': provider = 'akamai'
        elif provider_id == '2': provider = 'limelight'
        elif provider_id == '3': provider = 'level3'

        return provider

    def get_protocol(self):
        protocol = "rtmp"
        try:
            protocol_id = self.Settings().get_setting('protocol')
        except:
            pass

        if protocol_id == '1': protocol = 'rtmpt'

        return protocol

    def get_port(self):
        port = 1935
        protocol = self.get_protocol()
        if protocol == 'rtmpt': port = 80
        return port
            
    
    def Resolve(self, url):
        return url
