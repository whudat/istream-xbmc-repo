'''
    Ice Channel
'''

from entertainment.plugnplay.interfaces import LiveTVIndexer
from entertainment.plugnplay.interfaces import LiveTVSource
from entertainment.plugnplay import Plugin
from entertainment import common

class qvc_beauty_uk(LiveTVIndexer, LiveTVSource):
    implements = [LiveTVIndexer, LiveTVSource]
    
    display_name = "QVC Beauty UK"
    
    name = 'qvc_beauty_uk'
    
    base_url = 'http://www.qvcuk.com/BeautyChannel.content.html'
    
    import xbmcaddon
    import os
    addon_id = 'script.icechannel.extn.uk'
    addon = xbmcaddon.Addon(addon_id)
    img = os.path.join( addon.getAddonInfo('path'), 'resources', 'images', name + '.png' )
    
    regions = [ 
            {
                'name':'United Kingdom', 
                'img':addon.getAddonInfo('icon'), 
                'fanart':addon.getAddonInfo('fanart')
                }, 
        ]
        
    languages = [ 
        {'name':'English', 'img':'', 'fanart':''}, 
        ]
        
    genres = [ 
        {'name':'Shopping', 'img':'', 'fanart':''} 
        ]
    
    addon = None
    
    def GetFileHosts(self, id, other_names, region, language, list, lock, message_queue):
        if id == self.name:
            self.AddLiveLink(list, self.display_name, self.base_url, language='English', region='United Kingdom')
    
    def Resolve(self, url):
        resolved_media_url = ''
        
        from entertainment.net import Net
        net = Net()
        net.http_GET(url, auto_read_response=False)
        
        video_config_url = 'http://www.qvcuk.com/wcsstore/UK/content/javascript/videoConfig.js'
        content = net.http_GET(video_config_url).content
        
        import re
        player = 'http://www.qvcuk.com/wcsstore/RAPIDStorefrontAssetStore/assets/flowplayer.rtmp-3.1.3.swf'
                    
        playpath = re.search('[\'"]url[\'"]:[\'"](QVCUKBeauty.+?)[\'"]', content)
        streamer = re.search('[\'"]netConnectionUrl[\'"]:[\'"](.+?)[\'"]', content)
    
        if streamer: streamer = streamer.group(1)
        if playpath: playpath = playpath.group(1)
    
        if not streamer and playpath and playpath.startswith('rtmp'):
            fs_index = playpath.rfind('/')
            if fs_index > 0:
                streamer = playpath[:fs_index]
                playpath = playpath[fs_index+1:]
                
        if streamer and playpath:
            if playpath.endswith('.flv'):
                playpath = playpath[:-4]
            elif playpath.endswith('.mp4'):
                playpath = 'mp4:' + playpath
                
            resolved_media_url = streamer + ' playpath=' + playpath + ' swfUrl=' + player + ' pageUrl=' + url + ' live=true timeout=20' 
    
        return resolved_media_url