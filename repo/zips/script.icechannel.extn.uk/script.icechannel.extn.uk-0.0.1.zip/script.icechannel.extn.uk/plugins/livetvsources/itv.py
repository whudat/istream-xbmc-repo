'''
    Ice Channel
'''

from entertainment.plugnplay.interfaces import LiveTVSource
from entertainment.plugnplay import Plugin
from entertainment import common

class itv(LiveTVSource):
    implements = [LiveTVSource]
    
    display_name = "ITV PLAYER"
    
    name = 'ITV PLAYER'
    
    source_enabled_by_default = 'true'


    def GetFileHosts(self, id, other_names, region, language, list, lock, message_queue):

        if id =='itv1':
            name='ITV 1'
            url='http://www.itv.com/mediaplayer/xml/channels.itv1.xml'
            self.AddLiveLink( list, name, url, language='English',host='ITV PLAYER' )
            
        if id =='itv4':
            name='ITV 4'
            url='http://www.itv.com/mediaplayer/xml/channels.itv4.xml'
            self.AddLiveLink( list, name, url, language='English',host='ITV PLAYER' )
     
                
        
            
    
    def Resolve(self, url):
        resolved_media_url = ''
        import re
        from entertainment.net import Net
        net = Net(cached=False)
        response = net.http_GET(url).content

        rtmp=re.compile('<MediaFiles base="(.+?)"').findall(response)
        playpath=re.compile('CDATA\[(.+?)\]').findall(response) 

        resolved_media_url=rtmp[0]+' playpath='+playpath[2]+' swfUrl=http://www.itv.com/mediaplayer/ITVMediaPlayer.swf?v=12.18.4 live=true timeout=10 swfvfy=true'
    
        return resolved_media_url
