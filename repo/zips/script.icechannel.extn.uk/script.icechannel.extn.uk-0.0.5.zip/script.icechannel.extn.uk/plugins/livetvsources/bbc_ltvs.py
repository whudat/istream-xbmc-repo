'''
    Ice Channel
'''

from entertainment.plugnplay.interfaces import LiveTVSource
from entertainment.plugnplay import Plugin
from entertainment import common
import xml.dom.minidom as dom

class bbciplayer(LiveTVSource):
    implements = [LiveTVSource]
    
    name = 'BBC iPlayer'
    display_name = 'BBC iPlayer'
    
    source_enabled_by_default = 'true'
     

    
    def parseXML(self,url):
        from entertainment.net import Net
        net = Net(cached=False)
        xml = net.http_GET(url).content
        doc = dom.parseString(xml)
        root = doc.documentElement
        return root

    def GetFileHosts(self, id, other_names, region, language, list, lock, message_queue):
        quality_dict = {'1500':'720P', '800':'HD', '560':'SD', '480':'SD', '396':'SD', '176':'LOW', '56':'LOW'}
        from entertainment.net import Net
        import re

        net = Net(cached=False)        
        stream_id = None
        
        if id =='bbc_one':
            stream_id='bbc_one_london'
        
        elif id =='bbc_two':
            stream_id='bbc_two_england'
        
        elif 'cbeeb' in id:
            stream_id='bbc_four'
        
        if not stream_id: return
        
        NEW_URL = 'http://www.bbc.co.uk/mediaselector/4/mtis/stream/%s' % stream_id  
        html = net.http_GET(NEW_URL).content
        
        match=re.compile('application="(.+?)".+?authString="(.+?)".+?identifier="(.+?)".+?protocol="(.+?)".+?server="(.+?)".+?supplier="(.+?)"').findall(html.replace('amp;',''))

        for app,auth , playpath ,protocol ,server,supplier in match:

            port = '1935'
            if protocol == 'rtmpt': port = 80
            if supplier == 'limelight':
                url="%s://%s:%s/ app=%s?%s tcurl=%s://%s:%s/%s?%s playpath=%s live=1" % (protocol,server,port,app,auth,protocol,server,port,app,auth,playpath)

                
            else:
               url="%s://%s:%s/%s?%s playpath=%s?%s live=1" % (protocol,server,port,app,auth,playpath,auth)
               
            
            res=playpath.split('inlet_')[1]
            if '@' in res:
                res=res.split('@')[0]

            self.AddLiveLink( list, id.replace('_',' ').upper(), url, language = language.title(),host= 'BBC iPLAYER '+supplier,quality=quality_dict.get(res, 'NA'))

    
    def Resolve(self, url):
        return url
