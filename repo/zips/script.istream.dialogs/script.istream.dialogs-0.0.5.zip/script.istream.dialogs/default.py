addon_id="script.istream.dialogs"
addon_name="iSTREAM Custom Windows and Dialogs"